

n8n mongoDB node delete bug : https://community.n8n.io/t/mongo-delete-document-with-id/17551/4